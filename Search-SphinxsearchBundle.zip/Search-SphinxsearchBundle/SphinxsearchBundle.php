<?php

namespace Search\SphinxsearchBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SphinxsearchBundle extends Bundle
{
}
